package dynamic_programming;
import java.util.Arrays;
public class LongestIncreasingSubsequence {
    public static void main(String[] args) {
        int[] arr={10, 22, 9, 33, 21, 50, 41, 0, 8};
        int[] dp=new int[arr.length];
        Arrays.fill(dp,1);
        for(int i=1;i<arr.length;i++){
            for(int j=0;j<i;j++){
                if(arr[j]<arr[i] && dp[i]<dp[j]+1){
                    dp[i]=dp[j]+1;
                }
            }
        }
        for(int v:dp){
            System.out.print(v+" ");
        }
    }
}

package dynamic_programming;
import java.util.*;
public class box{
    public static void main(String args[]){
        Integer[] boxes={7,2,13,12,9,1};
        ArrayList<Integer> boxes2=new ArrayList<>();
        for(int v:boxes){
            boxes2.add(v);
        }
        // List<Integer> arr=Arrays.asList(boxes);
        PriorityQueue<Integer> pq=new PriorityQueue<>(Arrays.asList(boxes));
        HashMap<Integer,Boolean> mp=new HashMap<>();
        int ans=0;
        while(!pq.isEmpty()){
            int x=pq.poll();
            int i=boxes2.indexOf(x);
            if(mp.getOrDefault(i, false)==false){
                mp.put(i,true);
                mp.put(i-1,true);
                mp.put(i+1,true);
                ans+=x;
            }
            else{
                continue;
            }
        }
        System.out.println(ans);
        // int [] dp=new int[boxes.length];
        // dp[0]=boxes[0];
        // dp[1]=Math.min(dp[0],boxes[1]);
        // for(int i=2;i<boxes.length;i++){
        //     dp[i]=Math.min(dp[i-1],dp[i-2]+boxes[i]);
        // }
        // System.out.println(Arrays.toString(dp));

    }
}
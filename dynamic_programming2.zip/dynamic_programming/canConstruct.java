package dynamic_programming;
import java.util.*;
public class canConstruct {
    public static boolean check2(String[] arr,String word,HashMap<String,Boolean>myMap){
        if(myMap.containsKey(word)){
            return myMap.get(word);
        }
        if(word==""){
            return true;
        }
        for(String v:arr){
            if(word.indexOf(v)==0){
                String h=word.substring(v.length());
                if(check2(arr,h,myMap)==true){
                    myMap.put(h,true);
                    // System.out.println(h);
                    return true;
                }
            }
        }
        myMap.put(word,false);
        return false;
    }
    public static int check(String[] arr,String word,HashMap<String,Integer>myMap){
        if(myMap.containsKey(word)){
            return myMap.getOrDefault(word,0);
        }
        if(word==""){
            return 1;
        }
        int totalCount=0;
        for(String v:arr){
            if(word.indexOf(v)==0){
                String h=word.substring(v.length());
                totalCount+=check(arr,h,myMap);
            }
        }
        myMap.put(word,totalCount);
        return totalCount;
    }
    // public static ArrayList<ArrayList<String>> allwords(String[] arr,String word,HashMap<String,ArrayList<String>>HashMap){
    //     if(word==""){
    //         return new ArrayList<ArrayList<String>>();
    //     }
    //     for(String v:arr){
    //         if(word.indexOf(v)==0){
    //             String h=word.substring(v.length());
                
    //         }
    //     }
        

    // }
    public static void main(String[] args) {
        String word="skateboarding";
        HashMap<String,Boolean> myMap2=new HashMap<>();
        HashMap<String,Integer> myMap=new HashMap<>();
        String[] arr={"bo","rd","ate","t","sk","board"};
        System.out.println(check(arr,word,myMap));
        System.out.println(check2(arr,word,myMap2));
    }
}

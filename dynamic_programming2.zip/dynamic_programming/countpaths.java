package dynamic_programming;
import java.util.*;
public class countpaths {
    public static void main(String[] args) {
        int[][] arr={{0,1,1,1,1},{0,0,0,1,1},{0,1,0,0,0},{0,0,0,0,0}};
        int r=arr.length,c=arr[0].length;
        int[][] dp=new int[r][c];
        dp[0][0]=1;
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                if(i!=0 || j!=0){
                    if(arr[i][j]==0){
                        if(i-1>=0){
                            dp[i][j]+=dp[i-1][j];
                        }
                        if(j-1>=0){
                            dp[i][j]+=dp[i][j-1];
                        }
                    }
                }
            }
        }
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                System.out.print(dp[i][j]+" ");
            }
            System.out.println();
        }
        System.out.println(dp[r-1][c-1]);
    }
}

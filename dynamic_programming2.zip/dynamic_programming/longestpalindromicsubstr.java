package dynamic_programming;

import java.util.HashMap;
import java.util.TreeMap;

public class longestpalindromicsubstr {
    public static String reverse(String str) {
        String ans="";
        for(int i=0;i<str.length();i++){
            ans=str.charAt(i)+ans;
        }
        return ans;
    }
    public static boolean dp(String s,HashMap<String,Integer>myMap,TreeMap<Integer,String>treeMap){
        if(myMap.containsKey(s)){
            return true;
        }
        if(s.equalsIgnoreCase(reverse(s))){
            treeMap.put(s.length(),s);
            return true;
        }
        // System.out.println(s);
        String h=s.substring(1);

        if(dp(h,myMap,treeMap)==true){
            myMap.put(h,h.length());
        }
        String s2=reverse(s);
        // System.out.println(s2);
        String h2=s2.substring(1);
        h2=reverse(h2);
        if(dp(h2,myMap,treeMap)==true){
            myMap.put(h2,h2.length());
        }
        return false;
    }
    public static String longestPalindrome(String s) {
        HashMap<String,Integer> myMap=new HashMap<>();
        TreeMap<Integer,String>treeMap=new TreeMap<>();
        dp(s,myMap,treeMap);
        System.out.println(treeMap);
        return treeMap.get(treeMap.lastKey());
    }
    public static void main(String[] args) {
        System.out.println(longestPalindrome("babad"));
    }
}

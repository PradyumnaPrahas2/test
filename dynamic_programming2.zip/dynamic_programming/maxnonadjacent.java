package dynamic_programming;
import java.util.*;
public class maxnonadjacent {
    public static void main(String[] args) {
        int[] arr={ 5, 5, 10, 100, 10, 5 };
        arr[2]=Math.max(arr[2],arr[2]+arr[0]);
        for(int i=3;i<arr.length;i++){
            arr[i]=Math.max(arr[i]+arr[i-2],arr[i]+arr[i-3]);
        }
        for(int v:arr){
        System.out.print(v+" ");}
    }
}

package dynamic_programming;
import java.util.Arrays;
public class maxpath {
    public static void main(String[] args) {
        int[][] arr={{1,2,3,4,5},{6,4,2,3,1},{0,1,0,0,0},{10,21,3,6,9}};
        int r=arr.length,c=arr[0].length;
        int[][] dp=new int[r][c];
        for(int i=0;i<r;i++){
        Arrays.fill(dp[i],Integer.MAX_VALUE);}
        dp[0][0]=arr[0][0];
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                if(i!=0 || j!=0){
                    if(i-1>=0){
                        dp[i][j]=Math.min(dp[i][j],arr[i][j]+dp[i-1][j]);
                    }
                    if(j-1>=0){
                        dp[i][j]=Math.min(dp[i][j],arr[i][j]+dp[i][j-1]);
                    }
                }
            }
        }
        System.out.println(dp[r-1][c-1]);
    }
}

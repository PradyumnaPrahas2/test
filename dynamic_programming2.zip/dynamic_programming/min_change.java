package dynamic_programming;
import java.util.*;
public class min_change {
    public static int ans=Integer.MAX_VALUE;
    public static void find(int[] arr,int t,ArrayList<Integer> a){
        if(t==0){
            ans=Math.min(ans,a.size());
            return;
        }
        if(t<0){
            return;
        }
        for(int i=0;i<arr.length;i++){
            if(arr[i]<=t){
                a.add(arr[i]);
                find(arr,t-arr[i],a);
                a.remove(a.size()-1);
            }
        }
    }
    public static void tabulate(int[] arr,int target){
        int[] dp=new int[target+1];
        Arrays.fill(dp,Integer.MAX_VALUE);
        dp[0]=0;
        for(int i=1;i<=target;i++){
            for(int j=0;j<arr.length;j++){
                if(i-arr[j]>=0 && dp[i-arr[j]]!=Integer.MAX_VALUE){
                    dp[i]=Math.min(dp[i],dp[i-arr[j]]+1);
                }
            }
        }
        System.out.print(dp[target]);
    }
    public static void main(String[] args){
        int[] arr={1,2,5};
        int target=11;
        ArrayList<Integer> a=new ArrayList<>();
        find(arr,target,a);//Memoization
        System.out.println(ans);
        System.out.println(target);
        tabulate(arr,target);// Tabulation
    }
}

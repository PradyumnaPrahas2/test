package dynamic_programming;
import java.util.*;
public class targetsum {
    public static boolean func(int[] arr,int target,HashMap<Integer,Boolean>myMap){
        if(myMap.containsKey(target)){
            return myMap.getOrDefault(target,false);
        }
        if(target==0){
            return true;
        }
        if(target<0){
            return false;
        }
        for(int v:arr){

            if(func(arr,target-v,myMap)==true){
                myMap.put(target-v,true);
                return true;
            }
        }
        myMap.put(target,false);
        return false;
    }
    public static ArrayList<ArrayList<ArrayList<Integer>>>allcomb=new ArrayList<>();
    public static ArrayList<Integer> how(int[] arr,int target,ArrayList<Integer>elements,HashMap<Integer,ArrayList<Integer>>myMap,int t){
        if(myMap.containsKey(target)){
            return myMap.getOrDefault(target,null);
        }
        if (target == 0) {
            return new ArrayList<>(elements);
        }
        if (target < 0) {
            return null;
        }
        ArrayList<Integer>bestComb=null;
        for (int v : arr) {
            ArrayList<Integer> result = how(arr, target - v, elements,myMap,t);
            if (result != null) {
                result.add(v);
                int sum=result.stream().mapToInt(Integer::intValue).sum();
                if(sum==t){
                    System.out.println(result);
                }
                if (bestComb == null || result.size() < bestComb.size()) {
                    bestComb = new ArrayList<>(result); 
                    
                }
            }
        }
        myMap.put(target, bestComb);
        return bestComb; 
    }
    public static ArrayList<ArrayList<Integer>>allcom=new ArrayList<>();
    public static ArrayList<Integer> allcombinations(int[] arr2,int target,ArrayList<Integer>elements2,HashMap<Integer,ArrayList<Integer>>myMap2){
        if(myMap2.containsKey(target)){
            return myMap2.getOrDefault(target,null);
        }
        if (target == 0) {
            return new ArrayList<>(elements2);
        }
        if (target < 0) {
            return null;
        }
        ArrayList<Integer>bestComb=null;
        for (int v : arr2) {
            ArrayList<Integer> result = allcombinations(arr2, target - v, elements2,myMap2);
            if (result != null) {
                result.add(v);
                System.out.println(result);
                if (bestComb == null || result.size() < bestComb.size() || result.size()>=bestComb.size()) {
                    bestComb = new ArrayList<>(result); 
                    
                    System.out.println("hi");
                    allcom.add(bestComb);
                }
            }
        }
        myMap2.put(target, bestComb);
        return bestComb; 
    }
    public static void main(String[] args){
        // int [] arr={16,4,4,12};
        // int target=28;
        // if(target!=0){
        // HashMap<Integer,Boolean>myMap=new HashMap<>();
        // System.out.println(func(arr,target,myMap));
        // }
        // else{
        //     System.out.println(false);
        // }
        int [] arr2={1,2,4,6};
        int[] arr3={1,2,4,6};
        int target2=4;
        int target3=4;
        HashMap<Integer,ArrayList<Integer>>myMap2=new HashMap<>();
        ArrayList<Integer>elements=new ArrayList<>();
        if(target2!=0){
            ArrayList<Integer> answer=how(arr2,target2,elements,myMap2,target2);
            int sum=0;
            for (int i: answer){
                sum+=i;
            }
            if(sum==target2){
                System.out.println(answer);
            }
            else{
                System.out.println("Not possible!");
            }
            System.out.println(answer);
        }
        else{
            System.out.println(elements);
        }
        // System.out.println("All combinations are:-");
        // if(target2!=0){
        //     ArrayList<Integer> answer=allcombinations(arr3,target3,elements,myMap2);
        //     System.out.println(answer);
        // }
        // for(ArrayList<Integer> r:allcom){
        //     System.out.println(r);
        // }
    }
}

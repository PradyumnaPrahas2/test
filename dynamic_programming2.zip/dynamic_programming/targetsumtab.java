package dynamic_programming;
import java.util.*;
public class targetsumtab{
    private static HashMap<String,Integer> memo=new HashMap<>();
    private static ArrayList<String> findall(int[] num,int target){
        ArrayList<ArrayList<String>> comb=new ArrayList<>();
        for(int i=0;i<target+1;i++){
            comb.add(new ArrayList<>());
        }
        comb.get(0).add("");
        for(int i=1;i<=target;i++){
            for(int n:num){
                if(i>=n){
                    ArrayList<String> f=comb.get(i-n);
                    for(String s:f){
                        if(s.length()>0 && ""+s.charAt(s.length()-1)==""+n){
                            continue;
                        }
                        else{
                        String a=""+s+n;
                        comb.get(i).add(a);}
                    }
                }
            }
        }
        return comb.get(target);
    }
    private static int memoization(int[] num,int target,int last){
        if(target==0){
            return 1;
        }
        if(target<0){
            return 0;
        }
        int c=0;
        String s=target+","+last;
        if(memo.containsKey(s)){
            return memo.get(s);
        }
        for(int n:num){
            if(n==4 & last==4){
                continue;
            }
            else{
                c+=memoization(num,target-n,n);
            }
        }
        memo.put(s,c);
        return c;
    }
    public static void main(String args[]){
        int[] num={1,1,1};
        int target=3;
        // ArrayList<String> arr=findall(num,target);// Tabulation occupies extra heap memory
        // System.out.println(arr.size());
        // for(String a:arr){
        //     System.out.println(a);
        
        int c=memoization(num,target,-1);
        System.out.println(c);
        // }
    }
}
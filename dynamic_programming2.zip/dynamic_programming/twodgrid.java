package dynamic_programming;
import java.util.*;
public class twodgrid {
    public static int calculate(int i,int j,HashMap<String,Integer>myMap){
        String key=i+","+j;
        if(myMap.containsKey(key)){
            return myMap.getOrDefault(key, 0);
        }
        if(i==0 || j==0){
            return 0;
        }
        if(i==1 && j==1){
            return 1;
        }
        myMap.put(key,calculate(i-1,j,myMap)+calculate(i,j-1,myMap));
        return myMap.getOrDefault(key,0);
    }
    public static void main(String[] args){
        HashMap<String,Integer> myMap=new HashMap<>();
        System.out.println(calculate(13,18,myMap));//Memoization
        int [][] dp=new int[20][20];//Tabulation
        dp[0][0]=1;
        for(int i=0;i<20;i++){
            for(int j=0;j<20;j++){
                if(i==0 && j==0){
                    continue;
                }
                else{
                    if(i-1>=0){
                        dp[i][j]+=dp[i-1][j];
                    }
                    if(j-1>=0){
                        dp[i][j]+=dp[i][j-1];
                    }
                }
            }
        }

        System.out.println(dp[12][17]);
    }
}
